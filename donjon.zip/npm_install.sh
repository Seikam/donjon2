npm i fs discord.js@14 ppfun-captcha node-svg2img dotenv @napi-rs/canvas somefunctions
